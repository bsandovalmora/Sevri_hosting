﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SEVRI.Models
{
    public class Metodos
    {

        SEVRIDataContext d = new SEVRIDataContext();

    }
}