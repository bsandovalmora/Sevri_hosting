﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SEVRI.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Diccionario()
        {
            return View();
        }

        public ActionResult Generales()
        {
            return View();
        }

        public ActionResult Especificos()
        {
            return View();
        }

        public ActionResult Analisis()
        {
            return View();
        }

        public ActionResult InicioSesion()
        {
            return View();
        }

        public ActionResult Administracion()
        {
            return View();
        }

    }
}